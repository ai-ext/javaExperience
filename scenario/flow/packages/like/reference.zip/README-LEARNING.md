# 좋아요 완성 참고 답안 · reference

이 ZIP은 정본4-1의 파일별 blob82개로 재구성한 별도 프로젝트입니다.
현재 미구현 메서드: 없음
좋아요 제공 메서드: like·unlike 모두 제공
앞 CRUD 다섯 기능은 정본 구현입니다. 기존 프로젝트 위에 풀면 사용자 구현을 덮어쓰므로,
중간 합류가 필요한 경우에만 반드시 새 폴더에 풉니다. 기존 프로젝트에서 이어가려면
like-extension.zip의 새 파일과 작은 patch만 추가합니다.

DB는 앞 과제의 community를 계속 사용합니다. 새 폴더에서 Compose를 다시 만들거나 DB를
초기화하지 않습니다. 기존 앱만 종료하고 새 폴더에서 chmod +x gradlew 후
./gradlew compileJava, ./gradlew bootRun으로 실행합니다. JDK21·Gradle9.8.0이며
기본 DB는 localhost:13308/community입니다. 다른 DB 포트였다면 기존
SPRING_DATASOURCE_URL을 유지합니다. 원래 starter의 상세 준비 안내도 참고합니다.

원문 snapshot의 commit tree가 아닌 files[].blob이 출처입니다. 추가 wrapper/Compose 파일의
출처는 PACKAGE-MANIFEST.json의 supplementalFiles에 별도 기록합니다.
미구현 메서드를 호출하는 테스트는 완성 전 실패합니다. compile 성공은 기능 완료가 아닙니다.
완성 참고 답안은 직접 구현한 뒤 비교합니다.

같은 서버에서 다른 회원이 새 PUBLIC 글을 POST한 실제 id를 기록합니다.
교육용 작성 tok-park, 좋아요 tok-kimjava를 각 화면에 수동 입력합니다.
삭제한 CRUD id나 고정 예시42를 이어받지 않습니다. PUT·DELETE 본문 없음/200,
순차 PUT→PUT→DELETE→DELETE의 상태·관계·카운터를 확인합니다.

package org.example.like;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PostLikeRepository extends JpaRepository<PostLike, Long> {

    boolean existsByPost_IdAndMember_Id(Long postId, Long memberId);

    long deleteByPost_IdAndMember_Id(Long postId, Long memberId);
}

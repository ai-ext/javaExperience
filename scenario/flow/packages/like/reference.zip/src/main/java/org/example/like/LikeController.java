package org.example.like;

import org.example.auth.AuthenticatedMember;
import org.example.auth.LoginMember;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LikeController {

    private final LikeService likeService;

    public LikeController(LikeService likeService) {
        this.likeService = likeService;
    }

    @PutMapping("/api/posts/{id}/like")
    public LikeResponse like(@PathVariable Long id, @LoginMember AuthenticatedMember loginMember) {
        return likeService.like(id, loginMember);
    }

    @DeleteMapping("/api/posts/{id}/like")
    public LikeResponse unlike(@PathVariable Long id, @LoginMember AuthenticatedMember loginMember) {
        return likeService.unlike(id, loginMember);
    }
}

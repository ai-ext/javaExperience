package org.example.like;

public record LikeResponse(Long postId, boolean liked, Integer likeCount) {
}

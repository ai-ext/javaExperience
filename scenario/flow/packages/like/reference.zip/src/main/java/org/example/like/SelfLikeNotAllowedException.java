package org.example.like;

// 내 글에는 좋아요를 누를 수 없다 — 전역 핸들러가 400으로 변환한다
public class SelfLikeNotAllowedException extends RuntimeException {

    public SelfLikeNotAllowedException() {
        super("내 글에는 좋아요를 누를 수 없습니다.");
    }
}

# 같은 프로젝트에 좋아요 기능 추가하기

이 ZIP은 기존 CRUD 프로젝트를 완성 코드로 교체하지 않습니다. 새 폴더 `like-extension`에
풀어 자료를 확인합니다. 압축 안에는 루트 src 경로가 없고 additions 아래 새 파일 6개와
기존 두 파일에 적용할 작은 patch만 있습니다. 자동 설치·복사·DB 초기화를 실행하지 않습니다.

## 준비 상태

앞의 작성·상세·목록·수정·삭제를 같은 프로젝트에서 직접 구현한 상태입니다.
PostService와 PostQueryService는 이 자료에 들어 있지 않으며 사용자의 구현을 유지합니다.
같은 community DB를 사용합니다. post_like 테이블·UNIQUE(post_id,member_id)는 기존 3-2 DDL에
이미 있으므로 SQL dump를 다시 넣거나 DB를 지우지 않습니다.

## 한 번만 추가할 파일

기존 앱만 종료합니다. 기존 프로젝트의 org/example/like 패키지에 같은 이름의 파일이
하나라도 있으면 전체 복사를 중단하고 기존 파일과 직접 대조합니다. 없을 때만 additions의
LikeController.java, LikeResponse.java, LikeService.java, PostLike.java,
PostLikeRepository.java, SelfLikeNotAllowedException.java를 같은 경로에 추가합니다.
원본 파일을 덮어쓰지 않습니다. LikeService의 like·unlike 본문은 둘 다 미구현입니다.

post-like-support.patch는 Post.java에 increaseLikeCount·decreaseLikeCount를 추가하고,
ApiExceptionHandler.java에 자기 글 좋아요 400 handler를 추가합니다.
기존 CRUD 메서드는 바꾸지 않습니다. 기존 프로젝트 터미널에서 먼저
`git apply --check ../like-extension/post-like-support.patch`로 전체 적용 가능 여부를 확인하고,
성공한 경우에만 `git apply ../like-extension/post-like-support.patch`를 실행합니다.
이 명령은 프로젝트와 like-extension을 같은 상위 폴더에 둔 경우입니다.
확인 실패는 이미 적용했거나 코드 문맥이 다른 경우이므로 강제 적용하지 않습니다.
patch의 두 작은 추가 내용을 IDE에서 대조해 직접 반영합니다. 정본 파일 전체로 교체하지 않습니다.

## 구현 순서

1. LikeService.java#like: PUT /api/posts/{id}/like. 현재 관계가 없을 때만 추가하고 숫자를 늘립니다.
2. LikeService.java#unlike: DELETE /api/posts/{id}/like. 현재 관계가 있을 때만 제거하고 숫자를 줄입니다.

두 메서드의 @Transactional·Controller·DTO·helper는 제공됩니다. 요청 본문은 없고 두 API 모두
200과 postId/liked/likeCount를 응답합니다. like를 구현하는 동안 아직 unlike를 호출하면
미구현 오류가 나며, 이것을 PUT 과제의 실패로 보지 않습니다.
코드를 저장한 뒤 `./gradlew compileJava`, `./gradlew bootRun`으로 앱만 다시 실행합니다.
DB 포트를 바꿨다면 앞 과제에서 사용한 SPRING_DATASOURCE_URL을 그대로 사용합니다.

## 삭제한 글이나 본인 글을 성공 예제로 사용하지 않기

마지막 CRUD에서 삭제한 id는 좋아요에 사용하면 404입니다. 같은 프로젝트의 기존 POST를
다시 사용해 다른 회원이 dev에 새 PUBLIC 글을 만들고 응답 id를 기록합니다.
공개 교육용 seed에서는 작성 tok-park(회원4), 좋아요 요청 tok-kimjava(회원2) 조합을 씁니다.
서로 다른 회원임을 실제 응답 author와 DB에서 확인합니다. 토큰은 수동 입력하며 자동 저장하지 않습니다.
고정 3이나 시각화의 42를 실제 생성 id 대신 사용하지 않습니다.
PUT 자기 글은400이지만 관계 없는 본인 글 DELETE는200·liked=false입니다.

같은 id·같은 회원으로 PUT→PUT→DELETE→DELETE를 보내 전체 카운트와 내 관계 수를 확인합니다.
다른 회원의 좋아요가 있으면 그 행은 남아야 합니다. 상태는 뒤집는 toggle이 아닙니다.
존재 확인+카운터 변경만으로 모든 동시 요청의 정합성이 해결되지는 않습니다. 동시성은 다음4-2입니다.
정답·원문은 scenario/ch4-like/4-1-like-toggle에 보존되어 있으며 직접 구현한 뒤 비교합니다.

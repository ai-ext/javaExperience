package org.example.post;

import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.ObjectMapper;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class PostDeleteControllerTest {
    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;
    @Autowired JdbcTemplate jdbc;
    @Autowired EntityManager em;

    @Test
    void softDeleteKeepsPostAndRelatedRows() throws Exception {
        var created = mockMvc.perform(post("/api/posts")
                        .header("Authorization", "Bearer tok-kimjava")
                        .contentType("application/json")
                        .content("{\"boardSlug\":\"dev\",\"title\":\"삭제 보존 검사\",\"content\":\"본문\",\"tags\":[\"spring\"]}"))
                .andExpect(status().isCreated()).andReturn();
        long id = objectMapper.readTree(created.getResponse().getContentAsString()).get("id").asLong();
        em.flush(); // JPA 생성 결과를 DB에 기록한 뒤 연관 행을 추가한다.
        jdbc.update("INSERT INTO post_like(post_id, member_id, created_at) VALUES (?, 3, CURRENT_TIMESTAMP)", id);
        jdbc.update("INSERT INTO comment(post_id, member_id, content, created_at, updated_at) "
                + "VALUES (?, 3, '남길 댓글', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)", id);

        mockMvc.perform(delete("/api/posts/{id}", id)
                        .header("Authorization", "Bearer tok-kimjava"))
                .andExpect(status().isNoContent());
        em.flush();
        mockMvc.perform(get("/api/posts/{id}", id)).andExpect(status().isNotFound());

        assertTrue(jdbc.queryForObject("SELECT deleted_at IS NOT NULL FROM post WHERE id=?", Boolean.class, id));
        assertEquals("삭제 보존 검사", jdbc.queryForObject("SELECT title FROM post WHERE id=?", String.class, id));
        assertEquals(1L, jdbc.queryForObject("SELECT COUNT(*) FROM post_like WHERE post_id=?", Long.class, id));
        assertEquals(1L, jdbc.queryForObject("SELECT COUNT(*) FROM comment WHERE post_id=?", Long.class, id));
        assertEquals(1L, jdbc.queryForObject("SELECT COUNT(*) FROM post_tag WHERE post_id=?", Long.class, id));
    }
}

package org.example.post;

import jakarta.persistence.EntityManagerFactory;
import org.hibernate.SessionFactory;
import org.hibernate.stat.Statistics;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

// 2-4: 페이지 크기와 상관없이 목록 조회의 SQL 문장 수가 일정한지(N+1이 없는지) 고정한다.
// generate_statistics=true는 application-test.yml(공용 설정)에 있다 — 테스트별로 따로 켜면
// Spring이 별도 컨텍스트를 만들어 같은 Testcontainers 컨테이너의 스키마를 두 번 초기화하려다 깨진다.
@SpringBootTest
@AutoConfigureMockMvc
class PostListQueryCountTest {

    @Autowired
    MockMvc mockMvc;

    @Autowired
    EntityManagerFactory entityManagerFactory;

    @Test
    void queryCountIsSameRegardlessOfPageSizeAndBounded() throws Exception {
        Statistics statistics = entityManagerFactory.unwrap(SessionFactory.class).getStatistics();

        statistics.clear();
        mockMvc.perform(get("/api/boards/free/posts").param("size", "5"))
                .andExpect(status().isOk());
        long countForSize5 = statistics.getPrepareStatementCount();

        statistics.clear();
        mockMvc.perform(get("/api/boards/free/posts").param("size", "20"))
                .andExpect(status().isOk());
        long countForSize20 = statistics.getPrepareStatementCount();

        assertTrue(countForSize5 > 0, "Hibernate SQL 계측이 실제로 켜져 있어야 한다");
        assertEquals(countForSize5, countForSize20,
                "size=5와 size=20의 SQL 문장 수가 같아야 한다(N+1이면 글 수만큼 늘어난다)");
        assertTrue(countForSize5 <= 5,
                "SQL 문장 수는 5개 이하여야 한다(실제: " + countForSize5 + ")");
    }
}

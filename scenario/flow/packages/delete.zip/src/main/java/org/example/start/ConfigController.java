package org.example.start;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConfigController {

    public record ConfigView(String appName, String greeting, int maxItems) {
    }

    private final String appName;
    private final String greeting;
    private final int maxItems;

    public ConfigController(@Value("${spring.application.name}") String appName,
                            @Value("${start.greeting}") String greeting,
                            @Value("${start.max-items}") int maxItems) {
        this.appName = appName;
        this.greeting = greeting;
        this.maxItems = maxItems;
    }

    @GetMapping("/api/start/config")
    public ConfigView config() {
        return new ConfigView(appName, greeting, maxItems);
    }
}

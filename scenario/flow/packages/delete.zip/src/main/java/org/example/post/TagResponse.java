package org.example.post;

public record TagResponse(String name) {
}

package org.example.post;

import org.example.auth.AuthenticatedMember;
import org.example.social.FollowRepository;
import org.example.social.MemberBlockRepository;
import org.springframework.stereotype.Component;

// "이 사람이 이 글을 볼 수 있나" 규칙을 한 곳에 모은다.
// 상세(GET /api/posts/{id})는 이 자바 코드로 판정하고, 목록(게시판 목록)은
// 같은 다섯 조건을 PostRepository의 JPQL(findViewableByBoard)로 옮겨 건다.
// 규칙을 바꿀 때는 두 곳을 같이 고쳐야 한다.
@Component
public class PostAccessPolicy {

    private static final String PUBLISHED = "PUBLISHED";
    private static final String DRAFT = "DRAFT";
    private static final String HIDDEN = "HIDDEN";
    private static final String FOLLOWERS = "FOLLOWERS";
    private static final String ADMIN_ROLE = "ADMIN";

    private final FollowRepository followRepository;
    private final MemberBlockRepository memberBlockRepository;

    public PostAccessPolicy(FollowRepository followRepository, MemberBlockRepository memberBlockRepository) {
        this.followRepository = followRepository;
        this.memberBlockRepository = memberBlockRepository;
    }

    public boolean canView(AuthenticatedMember viewer, Post post) {
        // 1. 삭제된 글은 작성자 본인도 못 본다
        if (post.getDeletedAt() != null) {
            return false;
        }

        Long viewerId = viewer == null ? null : viewer.id();
        Long authorId = post.getAuthor().getId();
        boolean isAuthor = viewerId != null && viewerId.equals(authorId);
        boolean isAdmin = viewer != null && ADMIN_ROLE.equals(viewer.role());

        // 2. 상태별 허용 — DRAFT는 작성자만, HIDDEN은 운영자만
        boolean statusOk = switch (post.getStatus()) {
            case PUBLISHED -> true;
            case DRAFT -> isAuthor;
            case HIDDEN -> isAdmin;
            default -> false;
        };
        if (!statusOk) {
            return false;
        }

        // 3. PUBLISHED + FOLLOWERS 공개는 작성자 본인이거나 팔로워만
        if (PUBLISHED.equals(post.getStatus()) && FOLLOWERS.equals(post.getVisibility()) && !isAuthor) {
            boolean follows = viewerId != null
                    && followRepository.existsByFollower_IdAndFollowee_Id(viewerId, authorId);
            if (!follows) {
                return false;
            }
        }

        // 4. 둘 사이에 차단이 있으면(어느 쪽이 차단했든) 못 본다
        if (viewerId != null && !isAuthor && isBlockedEitherWay(viewerId, authorId)) {
            return false;
        }

        // 5. 비로그인은 PUBLISHED+PUBLIC만 — 위 2·3에서 DRAFT/HIDDEN/FOLLOWERS를
        // 이미 걸러내므로 여기서 추가로 할 일은 없다.
        return true;
    }

    private boolean isBlockedEitherWay(Long a, Long b) {
        return memberBlockRepository.existsByBlocker_IdAndBlocked_Id(a, b)
                || memberBlockRepository.existsByBlocker_IdAndBlocked_Id(b, a);
    }
}

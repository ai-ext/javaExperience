package org.example.auth;

// 누구인지는 알지만(토큰은 유효) 회원 상태가 ACTIVE가 아님 — 전역 핸들러가 403으로 변환한다
public class MemberNotActiveException extends RuntimeException {

    public MemberNotActiveException(String message) {
        super(message);
    }
}

package org.example.post;

import java.util.List;

// 부분 수정 요청 — 보낸 필드만 바꾼다. null·생략은 "그대로"라는 뜻이라 Bean Validation
// 애노테이션(예: @NotBlank)을 쓰지 않는다(PostService가 non-null일 때만 검사한다).
// boardSlug는 의도적으로 필드가 없다 — 게시판은 못 옮기므로 보내도 무시한다.
public record PostUpdateRequest(
        String title,
        String content,
        List<String> tags,
        String visibility
) {
}

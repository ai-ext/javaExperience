package org.example.post;

import jakarta.validation.constraints.NotBlank;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MemberPostController {

    private final PostQueryService postQueryService;

    public MemberPostController(PostQueryService postQueryService) {
        this.postQueryService = postQueryService;
    }

    @GetMapping("/api/members/{memberId}/posts")
    public List<PostHeadlineResponse> list(@PathVariable Long memberId,
                                            @RequestParam @NotBlank String board) {
        return postQueryService.listPublicByAuthor(memberId, board);
    }
}

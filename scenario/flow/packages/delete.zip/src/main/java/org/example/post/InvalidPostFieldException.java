package org.example.post;

// PATCH로 보낸 필드 값이 규칙에 안 맞을 때(빈 제목, 태그 개수 초과 등) — 전역 핸들러가 400으로 변환한다
public class InvalidPostFieldException extends RuntimeException {

    private final String field;

    public InvalidPostFieldException(String field, String message) {
        super(message);
        this.field = field;
    }

    public String getField() {
        return field;
    }
}

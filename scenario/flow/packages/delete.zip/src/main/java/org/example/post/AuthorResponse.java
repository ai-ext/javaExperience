package org.example.post;

public record AuthorResponse(Long id, String nickname) {
}

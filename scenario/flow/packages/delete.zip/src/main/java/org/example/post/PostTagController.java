package org.example.post;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/posts")
public class PostTagController {

    private final PostTagService postTagService;

    public PostTagController(PostTagService postTagService) {
        this.postTagService = postTagService;
    }

    @GetMapping("/{postId}/tags")
    public ResponseEntity<List<TagResponse>> listTags(@PathVariable Long postId) {
        return ResponseEntity.ok(postTagService.listTags(postId));
    }
}

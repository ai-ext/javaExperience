package org.example.start;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
public class MemberController {

    public record MemberView(Long id, String nickname) {
    }

    private static final Map<Long, String> NICKNAMES = Map.of(1L, "kimjava", 2L, "leespring");

    @GetMapping("/api/start/members/{id}")
    public MemberView find(@PathVariable Long id) {
        String nickname = NICKNAMES.get(id);
        if (nickname == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "없는 회원: " + id);
        }
        return new MemberView(id, nickname.toUpperCase());
    }
}

package org.example.auth;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.example.member.Member;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.cors.CorsUtils;
import org.springframework.web.servlet.HandlerInterceptor;

import java.time.Clock;
import java.time.LocalDateTime;

// /api/** 요청의 토큰을 한 곳에서 확인한다(컨트롤러마다 반복하지 않는다).
// GET이고 헤더가 없으면 비로그인으로 통과시킨다(2-1에서 필요).
@Component
public class AuthInterceptor implements HandlerInterceptor {

    public static final String LOGIN_MEMBER_ATTRIBUTE = "loginMember";
    private static final String BEARER_PREFIX = "Bearer ";
    private static final String ACTIVE_STATUS = "ACTIVE";

    private final ApiTokenRepository apiTokenRepository;
    private final Clock clock;

    public AuthInterceptor(ApiTokenRepository apiTokenRepository, Clock clock) {
        this.apiTokenRepository = apiTokenRepository;
        this.clock = clock;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        // CORS 사전 요청(OPTIONS)은 토큰 없이 온다 — 막으면 브라우저의 요청이 전부 CORS로 실패한다
        if (CorsUtils.isPreFlightRequest(request)) {
            return true;
        }

        String header = request.getHeader(HttpHeaders.AUTHORIZATION);
        boolean isGet = HttpMethod.GET.matches(request.getMethod());

        if (header == null) {
            if (isGet) {
                return true;
            }
            throw new AuthenticationRequiredException("인증이 필요합니다.");
        }
        if (!header.startsWith(BEARER_PREFIX)) {
            throw new AuthenticationRequiredException("인증이 필요합니다.");
        }

        String token = header.substring(BEARER_PREFIX.length()).trim();
        ApiToken apiToken = apiTokenRepository.findByTokenFetchMember(token)
                .orElseThrow(() -> new AuthenticationRequiredException("인증이 필요합니다."));

        LocalDateTime now = LocalDateTime.now(clock);
        boolean expired = !now.isBefore(apiToken.getExpiresAt());
        if (apiToken.getRevokedAt() != null || expired) {
            throw new AuthenticationRequiredException("인증이 필요합니다.");
        }

        Member member = apiToken.getMember();
        if (!ACTIVE_STATUS.equals(member.getMemberStatus())) {
            throw new MemberNotActiveException("정지되었거나 탈퇴한 회원입니다.");
        }

        request.setAttribute(LOGIN_MEMBER_ATTRIBUTE,
                new AuthenticatedMember(member.getId(), member.getNickname(), member.getRole()));
        return true;
    }
}

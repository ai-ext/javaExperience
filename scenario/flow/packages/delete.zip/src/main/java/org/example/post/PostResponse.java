package org.example.post;

import java.time.LocalDateTime;
import java.util.List;

// 게시글 작성 응답 전용 DTO — 요청 DTO나 엔티티를 그대로 돌려주지 않는다
public class PostResponse {
    private final Long id;
    private final String boardSlug;
    private final String title;
    private final String content;
    private final List<String> tags;
    private final String visibility;
    private final AuthorResponse author;
    private final LocalDateTime createdAt;

    public PostResponse(Long id, String boardSlug, String title, String content,
                        List<String> tags, String visibility, AuthorResponse author,
                        LocalDateTime createdAt) {
        this.id = id;
        this.boardSlug = boardSlug;
        this.title = title;
        this.content = content;
        this.tags = tags;
        this.visibility = visibility;
        this.author = author;
        this.createdAt = createdAt;
    }

    public Long getId() { return id; }
    public String getBoardSlug() { return boardSlug; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public List<String> getTags() { return tags; }
    public String getVisibility() { return visibility; }
    public AuthorResponse getAuthor() { return author; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}

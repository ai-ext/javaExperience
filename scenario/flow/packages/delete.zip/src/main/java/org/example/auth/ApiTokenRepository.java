package org.example.auth;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.lang.NonNull;

import java.util.Optional;

public interface ApiTokenRepository extends JpaRepository<ApiToken, Long> {

    // member를 함께 fetch해서 트랜잭션 밖(인터셉터)에서도 LazyInitializationException 없이 읽는다
    @Query("SELECT t FROM ApiToken t JOIN FETCH t.member WHERE t.token = :token")
    Optional<ApiToken> findByTokenFetchMember(@Param("token") @NonNull String token);
}

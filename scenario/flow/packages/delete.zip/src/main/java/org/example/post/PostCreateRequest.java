package org.example.post;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;

// 게시글 작성 요청 — Bean Validation으로 저장 전에 막는다
public record PostCreateRequest(
        @NotBlank(message = "게시판을 선택해 주세요.")
        String boardSlug,

        @NotBlank(message = "제목을 입력해 주세요.")
        @Size(max = 200, message = "제목은 200자 이하여야 합니다.")
        String title,

        @NotBlank(message = "본문을 입력해 주세요.")
        String content,

        @Size(max = 5, message = "태그는 5개까지입니다.")
        List<@NotNull @Size(min = 1, max = 30, message = "태그 이름은 1~30자여야 합니다.") String> tags,

        @Pattern(regexp = "PUBLIC|FOLLOWERS", message = "공개 범위는 PUBLIC 또는 FOLLOWERS여야 합니다.")
        String visibility
) {
}

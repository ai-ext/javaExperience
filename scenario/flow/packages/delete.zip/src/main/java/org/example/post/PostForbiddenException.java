package org.example.post;

// 볼 수는 있지만(404는 아님) 작성자가 아니라서 고치거나 지울 수 없을 때 — 전역 핸들러가 403으로 변환한다
public class PostForbiddenException extends RuntimeException {

    public PostForbiddenException() {
        super("본인 글만 수정하거나 삭제할 수 있습니다.");
    }
}

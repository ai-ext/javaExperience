package org.example.post;

// 없는 글이거나(2-1) 볼 수 없는 글(2-3) — 둘 다 같은 404로 응답해 글의 존재 여부를 숨긴다
public class PostNotFoundException extends RuntimeException {

    public PostNotFoundException() {
        super("글을 찾을 수 없습니다.");
    }
}

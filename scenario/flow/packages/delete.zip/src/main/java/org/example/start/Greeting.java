package org.example.start;

// 응답 JSON의 모양. TS로 쓰면 type Greeting = { name: string; message: string; nameLength: number }
public record Greeting(String name, String message, int nameLength) {
}

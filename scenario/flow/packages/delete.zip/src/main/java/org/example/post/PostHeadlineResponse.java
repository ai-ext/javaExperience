package org.example.post;

public record PostHeadlineResponse(Long id, String title, String authorNickname, String boardSlug) {
}

package org.example.start;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EchoController {

    // 본문 DTO — JSON의 title·tags만 받는다(모르는 필드는 버린다)
    public record EchoBody(String title, List<String> tags) {
    }

    // 응답 — 어느 자리에서 온 값인지 이름에 적었다
    public record EchoResponse(Long fromPath, String fromQuery, String fromHeader, Object fromBody) {
    }

    // 본문을 Map으로 — 들어온 JSON을 키·값 그대로 받는다
    @PostMapping("/api/start/echo/{id}")
    public EchoResponse echo(@PathVariable Long id,
                             @RequestParam String q,
                             @RequestHeader("X-Client") String client,
                             @RequestBody Map<String, Object> body) {
        return new EchoResponse(id, q, client, body);
    }

    // 본문을 DTO로 — 정한 필드만 받는다
    @PostMapping("/api/start/echo/{id}/dto")
    public EchoResponse echoDto(@PathVariable Long id,
                                @RequestParam String q,
                                @RequestHeader("X-Client") String client,
                                @RequestBody EchoBody body) {
        return new EchoResponse(id, q, client, body);
    }
}

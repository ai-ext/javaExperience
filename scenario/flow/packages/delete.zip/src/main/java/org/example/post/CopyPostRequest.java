package org.example.post;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CopyPostRequest(
        @NotBlank @Size(max = 200) String title
) {
}

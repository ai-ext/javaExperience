package org.example.start;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingController {

    @GetMapping("/api/start/hello")
    public Greeting hello(@RequestParam(defaultValue = "익명") String name) {
        String message = name + "님, 반가워요";
        int nameLength = name.length();
        return new Greeting(name, message, nameLength);
    }
}

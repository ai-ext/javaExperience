package org.example.start;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProfileController {

    @Getter @Setter @NoArgsConstructor
    public static class ProfileRequest {
        @NotBlank private String name;
        @NotNull @Min(0) @Max(150) private Integer age;
    }

    @Getter @RequiredArgsConstructor
    public static class ProfileResponse {
        private final String name;
        private final int age;
        private final boolean adult;
    }

    @PostMapping("/api/start/profile")
    public ProfileResponse profile(@Valid @RequestBody ProfileRequest request) {
        return new ProfileResponse(
                request.getName(), request.getAge(), request.getAge() >= 19);
    }
}

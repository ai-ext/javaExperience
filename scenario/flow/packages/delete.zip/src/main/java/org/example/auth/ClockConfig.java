package org.example.auth;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneId;

// 토큰 만료 판단의 기준 시각 — 테스트에서 시간을 고정할 수 있도록 빈으로 분리한다.
// app.fixed-now가 있으면(practice 프로파일, 8-2) 그 시각으로 고정하고, 없으면 시스템 시계를 쓴다.
@Configuration
public class ClockConfig {

    @Bean
    public Clock clock(@Value("${app.fixed-now:}") String fixedNow) {
        if (fixedNow == null || fixedNow.isBlank()) {
            return Clock.systemDefaultZone();
        }
        return Clock.fixed(
                LocalDateTime.parse(fixedNow).atZone(ZoneId.systemDefault()).toInstant(),
                ZoneId.systemDefault()
        );
    }
}

package org.example.start;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SummaryController {

    private static final int UNREAD_COUNT = 3;

    private static boolean hasNotice(int unreadCount) {
        return unreadCount > 0;
    }

    @GetMapping("/api/start/summary")
    public SummaryResponse summary() {
        String nickname = "김자바";
        return new SummaryResponse(
                UNREAD_COUNT,
                hasNotice(UNREAD_COUNT),
                nickname,
                SummaryResponse.class.getSimpleName()
        );
    }
}

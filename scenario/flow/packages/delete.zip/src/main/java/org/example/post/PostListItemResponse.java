package org.example.post;

import java.time.LocalDateTime;
import java.util.List;

// 목록 전용 DTO — 본문(content)을 넣지 않아 응답이 가볍다
public record PostListItemResponse(
        Long id,
        String title,
        AuthorResponse author,
        List<String> tags,
        Integer likeCount,
        Integer commentCount,
        Integer viewCount,
        LocalDateTime publishedAt
) {
}

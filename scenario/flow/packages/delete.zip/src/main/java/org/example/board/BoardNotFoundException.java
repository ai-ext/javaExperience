package org.example.board;

// 없는 게시판 slug로 요청했을 때 — 전역 핸들러가 404로 변환한다
public class BoardNotFoundException extends RuntimeException {

    public BoardNotFoundException(String slug) {
        super("게시판을 찾을 수 없습니다: " + slug);
    }
}

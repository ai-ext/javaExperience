package org.example.auth;

// 인터셉터가 토큰을 확인한 뒤 컨트롤러로 넘기는 로그인 회원 정보
public record AuthenticatedMember(Long id, String nickname, String role) {
}

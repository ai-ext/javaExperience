package org.example.post;

import java.time.LocalDateTime;
import java.util.List;

// 게시글 상세 조회 응답 — 작성 응답(PostResponse)과 달리 조회수·좋아요·댓글 수를 포함한다
public record PostDetailResponse(
        Long id,
        String boardSlug,
        String title,
        String content,
        List<String> tags,
        String visibility,
        AuthorResponse author,
        Integer viewCount,
        Integer likeCount,
        Integer commentCount,
        LocalDateTime createdAt
) {
}

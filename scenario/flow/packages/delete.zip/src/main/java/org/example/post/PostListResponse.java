package org.example.post;

import java.util.List;

// Page 객체를 그대로 직렬화하지 않고 목록 전용 응답 모양으로 고정한다
public record PostListResponse(
        List<PostListItemResponse> items,
        int page,
        int size,
        long totalElements,
        int totalPages,
        boolean hasNext
) {
}

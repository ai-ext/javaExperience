package org.example.start;

public record SummaryResponse(
        int unreadCount,
        boolean hasNotice,
        String nickname,
        String responseType
) {
}

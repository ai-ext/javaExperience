package org.example.board;

// 운영자 전용 게시판에 일반 회원이 쓰려고 할 때 — 전역 핸들러가 403으로 변환한다
public class BoardWriteForbiddenException extends RuntimeException {

    public BoardWriteForbiddenException(String slug) {
        super("이 게시판에는 글을 쓸 권한이 없습니다: " + slug);
    }
}

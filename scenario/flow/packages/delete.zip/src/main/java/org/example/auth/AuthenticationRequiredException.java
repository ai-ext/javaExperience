package org.example.auth;

// 누구인지 모름(헤더 없음·형식 오류·없는 토큰·만료·폐기) — 전역 핸들러가 401로 변환한다
public class AuthenticationRequiredException extends RuntimeException {

    public AuthenticationRequiredException(String message) {
        super(message);
    }
}

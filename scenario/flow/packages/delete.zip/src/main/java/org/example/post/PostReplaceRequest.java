package org.example.post;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;

public record PostReplaceRequest(
        @NotBlank @Size(max = 200) String title,
        @NotBlank String content,
        @Size(max = 5) List<@NotBlank @Size(max = 30) String> tags,
        @Pattern(regexp = "PUBLIC|FOLLOWERS") String visibility
) {
    public PostReplaceRequest {
        tags = tags == null ? List.of() : tags;
        visibility = visibility == null ? "PUBLIC" : visibility;
    }
}
